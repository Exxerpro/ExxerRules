using System.Text;

namespace ExxerFactor.Mcp.Core.Tests.Tools;

public class ExxerFactoringHelpersTests : IDisposable
{
    private readonly string _testDirectory;
    private readonly string _testSolutionPath;
    private readonly string _testFilePath;

    public ExxerFactoringHelpersTests()
    {
        _testDirectory = Path.Combine(Path.GetTempPath(), $"ExxerFactoringHelpersTests_{Guid.NewGuid()}");
        Directory.CreateDirectory(_testDirectory);
        _testSolutionPath = Path.Combine(_testDirectory, "TestSolution.sln");
        _testFilePath = Path.Combine(_testDirectory, "TestClass.cs");

        // Create test files
        CreateTestSolution();
    }

    [Fact]
    public void TryParseRange_WithValidRange_ShouldReturnTrue()
    {
        // Arrange
        var range = "10:5-15:10";

        // Act
        var result = ExxerFactoringHelpers.TryParseRange(range, out var startLine, out var startColumn, out var endLine, out var endColumn);

        // Assert
        result.ShouldBeTrue();
        startLine.ShouldBe(10);
        startColumn.ShouldBe(5);
        endLine.ShouldBe(15);
        endColumn.ShouldBe(10);
    }

    [Theory]
    [InlineData("invalid")]
    [InlineData("10:5")]
    [InlineData("10-15")]
    [InlineData("10:5-15:10-20")]
    [InlineData("")]
    [InlineData(null)]
    public void TryParseRange_WithInvalidRange_ShouldReturnFalse(string? range)
    {
        // Act
        var result = ExxerFactoringHelpers.TryParseRange(range ?? "", out var startLine, out var startColumn, out var endLine, out var endColumn);

        // Assert
        result.ShouldBeFalse();
        startLine.ShouldBe(0);
        startColumn.ShouldBe(0);
        endLine.ShouldBe(0);
        endColumn.ShouldBe(0);
    }

    [Fact]
    public void ValidateRange_WithValidRange_ShouldReturnTrue()
    {
        // Arrange
        var sourceText = SourceText.From("Line 1\nLine 2\nLine 3\nLine 4\nLine 5");
        var startLine = 2;
        var startColumn = 1;
        var endLine = 4;
        var endColumn = 5;

        // Act
        var result = ExxerFactoringHelpers.ValidateRange(sourceText, startLine, startColumn, endLine, endColumn, out var error);

        // Assert
        result.ShouldBeTrue();
        error.ShouldBeEmpty();
    }

    [Theory]
    [InlineData(0, 1, 2, 1, "Range values must be positive")]
    [InlineData(1, 0, 2, 1, "Range values must be positive")]
    [InlineData(1, 1, 0, 1, "Range values must be positive")]
    [InlineData(1, 1, 2, 0, "Range values must be positive")]
    public void ValidateRange_WithNonPositiveValues_ShouldReturnFalse(int startLine, int startColumn, int endLine, int endColumn, string expectedError)
    {
        // Arrange
        var sourceText = SourceText.From("Line 1\nLine 2\nLine 3");

        // Act
        var result = ExxerFactoringHelpers.ValidateRange(sourceText, startLine, startColumn, endLine, endColumn, out var error);

        // Assert
        result.ShouldBeFalse();
        error.ShouldContain(expectedError);
    }

    [Fact]
    public void ValidateRange_WithInvalidRangeOrder_ShouldReturnFalse()
    {
        // Arrange
        var sourceText = SourceText.From("Line 1\nLine 2\nLine 3");
        var startLine = 3;
        var startColumn = 1;
        var endLine = 1;
        var endColumn = 5;

        // Act
        var result = ExxerFactoringHelpers.ValidateRange(sourceText, startLine, startColumn, endLine, endColumn, out var error);

        // Assert
        result.ShouldBeFalse();
        error.ShouldContain("Range start must precede end");
    }

    [Fact]
    public void ValidateRange_WithRangeExceedingFileLength_ShouldReturnFalse()
    {
        // Arrange
        var sourceText = SourceText.From("Line 1\nLine 2\nLine 3");
        var startLine = 1;
        var startColumn = 1;
        var endLine = 5; // Exceeds file length
        var endColumn = 5;

        // Act
        var result = ExxerFactoringHelpers.ValidateRange(sourceText, startLine, startColumn, endLine, endColumn, out var error);

        // Assert
        result.ShouldBeFalse();
        error.ShouldContain("Range exceeds file length");
    }

    [Fact]
    public async Task ApplySingleFileEdit_WithValidTransform_ShouldApplyChanges()
    {
        // Arrange
        var originalContent = "Original content";
        await File.WriteAllTextAsync(_testFilePath, originalContent);
        var transform = (string content) => content.Replace("Original", "Modified");

        // Act
        var result = await ExxerFactoringHelpers.ApplySingleFileEdit(_testFilePath, transform, "Success");

        // Assert
        result.ShouldBe("Success");
        var modifiedContent = await File.ReadAllTextAsync(_testFilePath);
        modifiedContent.ShouldBe("Modified content");
    }

    [Fact]
    public async Task ApplySingleFileEdit_WithNonExistentFile_ShouldThrowException()
    {
        // Arrange
        var nonExistentPath = Path.Combine(_testDirectory, "NonExistent.cs");
        var transform = (string content) => content;

        // Act & Assert
        await Assert.ThrowsAsync<ExxerFactor.Mcp.Core.Exceptions.McpException>(() =>
            ExxerFactoringHelpers.ApplySingleFileEdit(nonExistentPath, transform, "Success"));
    }

    [Fact]
    public async Task ApplySingleFileEdit_WithErrorTransform_ShouldReturnError()
    {
        // Arrange
        await File.WriteAllTextAsync(_testFilePath, "content");
        var transform = (string content) => "Error: Something went wrong";

        // Act
        var result = await ExxerFactoringHelpers.ApplySingleFileEdit(_testFilePath, transform, "Success");

        // Assert
        result.ShouldBe("Error: Something went wrong");
    }

    [Fact]
    public async Task FindClassInSolution_WithExistingClass_ShouldReturnDocument()
    {
        // Arrange
        var solution = await ExxerFactoringHelpers.GetOrLoadSolution(_testSolutionPath);

        // Act
        var document = await ExxerFactoringHelpers.FindClassInSolution(solution, "TestClass");

        // Assert
        document.ShouldNotBeNull();
        document!.FilePath.ShouldBe(_testFilePath);
    }

    [Fact]
    public async Task FindClassInSolution_WithNonExistentClass_ShouldReturnNull()
    {
        // Arrange
        var solution = await ExxerFactoringHelpers.GetOrLoadSolution(_testSolutionPath);

        // Act
        var document = await ExxerFactoringHelpers.FindClassInSolution(solution, "NonExistentClass");

        // Assert
        document.ShouldBeNull();
    }

    [Fact]
    public async Task FindClassInSolution_WithExcludedFilePath_ShouldReturnNull()
    {
        // Arrange
        var solution = await ExxerFactoringHelpers.GetOrLoadSolution(_testSolutionPath);

        // Act
        var document = await ExxerFactoringHelpers.FindClassInSolution(solution, "TestClass", _testFilePath);

        // Assert
        document.ShouldBeNull();
    }

    [Fact]
    public async Task FindTypeInSolution_WithExistingType_ShouldReturnDocument()
    {
        // Arrange
        var solution = await ExxerFactoringHelpers.GetOrLoadSolution(_testSolutionPath);

        // Act
        var document = await ExxerFactoringHelpers.FindTypeInSolution(solution, "TestClass");

        // Assert
        document.ShouldNotBeNull();
        document!.FilePath.ShouldBe(_testFilePath);
    }

    [Fact]
    public async Task GetOrParseSyntaxTreeAsync_ShouldCacheAndReturnTree()
    {
        // Arrange
        var content = "public class TestClass { }";
        await File.WriteAllTextAsync(_testFilePath, content);

        // Act
        var tree1 = await ExxerFactoringHelpers.GetOrParseSyntaxTreeAsync(_testFilePath);
        var tree2 = await ExxerFactoringHelpers.GetOrParseSyntaxTreeAsync(_testFilePath);

        // Assert
        tree1.ShouldBeSameAs(tree2);
        tree1.GetRoot().DescendantNodes().OfType<ClassDeclarationSyntax>().Count().ShouldBe(1);
    }

    [Fact]
    public async Task GetOrCreateSemanticModelAsync_ShouldCacheAndReturnModel()
    {
        // Arrange
        var content = "public class TestClass { }";
        await File.WriteAllTextAsync(_testFilePath, content);

        // Act
        var model1 = await ExxerFactoringHelpers.GetOrCreateSemanticModelAsync(_testFilePath);
        var model2 = await ExxerFactoringHelpers.GetOrCreateSemanticModelAsync(_testFilePath);

        // Assert
        model1.ShouldBeSameAs(model2);
        model1.SyntaxTree.ShouldNotBeNull();
    }

    [Fact]
    public void UpdateFileCaches_ShouldUpdateCachedData()
    {
        // Arrange
        var originalContent = "public class OriginalClass { }";
        var newContent = "public class NewClass { }";

        // Act
        ExxerFactoringHelpers.UpdateFileCaches(_testFilePath, originalContent);
        var originalTree = ExxerFactoringHelpers.SyntaxTreeCache.Get<SyntaxTree>(_testFilePath);

        ExxerFactoringHelpers.UpdateFileCaches(_testFilePath, newContent);
        var newTree = ExxerFactoringHelpers.SyntaxTreeCache.Get<SyntaxTree>(_testFilePath);

        // Assert
        originalTree.ShouldNotBeSameAs(newTree);
        newTree!.GetRoot().DescendantNodes().OfType<ClassDeclarationSyntax>()
            .First().Identifier.Text.ShouldBe("NewClass");
    }

    [Fact]
    public async Task ReadFileWithEncodingAsync_ShouldDetectUtf8Encoding()
    {
        // Arrange
        var content = "public class TestClass { }";
        await File.WriteAllTextAsync(_testFilePath, content, Encoding.UTF8);

        // Act
        var (text, encoding) = await ExxerFactoringHelpers.ReadFileWithEncodingAsync(_testFilePath);

        // Assert
        text.ShouldBe(content);
        encoding.ShouldBe(Encoding.UTF8);
    }

    [Fact]
    public async Task ReadFileWithEncodingAsync_ShouldDetectUtf8WithBom()
    {
        // Arrange
        var content = "public class TestClass { }";
        var utf8WithBom = new UTF8Encoding(true);
        await File.WriteAllTextAsync(_testFilePath, content, utf8WithBom);

        // Act
        var (text, encoding) = await ExxerFactoringHelpers.ReadFileWithEncodingAsync(_testFilePath);

        // Assert
        text.ShouldBe(content);
        encoding.ShouldBe(utf8WithBom);
    }

    [Fact]
    public async Task WriteFileWithEncodingAsync_ShouldWriteWithSpecifiedEncoding()
    {
        // Arrange
        var content = "public class TestClass { }";
        var encoding = Encoding.UTF8;

        // Act
        await ExxerFactoringHelpers.WriteFileWithEncodingAsync(_testFilePath, content, encoding);

        // Assert
        var (readText, readEncoding) = await ExxerFactoringHelpers.ReadFileWithEncodingAsync(_testFilePath);
        readText.ShouldBe(content);
        readEncoding.ShouldBe(encoding);
    }

    [Fact]
    public async Task RunWithSolutionOrFile_WithDocumentInSolution_ShouldUseSolution()
    {
        // Arrange
        var solution = await ExxerFactoringHelpers.GetOrLoadSolution(_testSolutionPath);
        var document = ExxerFactoringHelpers.GetDocumentByPath(solution, _testFilePath);
        document.ShouldNotBeNull();

        var solutionCalled = false;
        var singleFileCalled = false;

        // Act
        var result = await ExxerFactoringHelpers.RunWithSolutionOrFile(
            _testSolutionPath,
            _testFilePath,
             (doc) => { solutionCalled = true; return Task.FromResult("solution"); },
             (path) => { singleFileCalled = true; return Task.FromResult("single"); });

        // Assert
        result.ShouldBe("solution");
        solutionCalled.ShouldBeTrue();
        singleFileCalled.ShouldBeFalse();
    }

    [Fact]
    public async Task RunWithSolutionOrFile_WithDocumentNotInSolution_ShouldUseSingleFile()
    {
        // Arrange
        var nonExistentPath = Path.Combine(_testDirectory, "NonExistent.cs");

        var solutionCalled = false;
        var singleFileCalled = false;

        // Act
        var result = await ExxerFactoringHelpers.RunWithSolutionOrFile(
            _testSolutionPath,
            nonExistentPath,
             (doc) => { solutionCalled = true; return Task.FromResult("solution"); },
             (path) => { singleFileCalled = true; return Task.FromResult("single"); });

        // Assert
        result.ShouldBe("single");
        solutionCalled.ShouldBeFalse();
        singleFileCalled.ShouldBeTrue();
    }

    [Fact]
    public void ClearAllCaches_ShouldClearAllCaches()
    {
        // Arrange
        ExxerFactoringHelpers.SolutionCache.Set("test", "value");
        ExxerFactoringHelpers.SyntaxTreeCache.Set("test", "value");
        ExxerFactoringHelpers.ModelCache.Set("test", "value");

        // Act
        ExxerFactoringHelpers.ClearAllCaches();

        // Assert
        ExxerFactoringHelpers.SolutionCache.TryGetValue("test", out _).ShouldBeFalse();
        ExxerFactoringHelpers.SyntaxTreeCache.TryGetValue("test", out _).ShouldBeFalse();
        ExxerFactoringHelpers.ModelCache.TryGetValue("test", out _).ShouldBeFalse();
    }

    [Fact]
    public void SharedWorkspace_ShouldReturnSameInstance()
    {
        // Act
        var workspace1 = ExxerFactoringHelpers.SharedWorkspace;
        var workspace2 = ExxerFactoringHelpers.SharedWorkspace;

        // Assert
        workspace1.ShouldBeSameAs(workspace2);
    }

    private void CreateTestSolution()
    {
        // Create a simple test solution structure
        var solutionContent = @"
Microsoft Visual Studio Solution File, Format Version 12.00
# Visual Studio Version 17
VisualStudioVersion = 17.0.31903.59
MinimumVisualStudioVersion = 10.0.40219.1
Project(""{FAE04EC0-301F-11D3-BF4B-00C04F79EFBC}"") = ""TestProject"", ""TestProject.csproj"", ""{12345678-1234-1234-1234-123456789012}""
EndProject
Global
	GlobalSection(SolutionConfigurationPlatforms) = preSolution
		Debug|Any CPU = Debug|Any CPU
		Release|Any CPU = Release|Any CPU
	EndGlobalSection
	GlobalSection(ProjectConfigurationPlatforms) = postSolution
		{12345678-1234-1234-1234-123456789012}.Debug|Any CPU.ActiveCfg = Debug|Any CPU
		{12345678-1234-1234-1234-123456789012}.Debug|Any CPU.Build.0 = Debug|Any CPU
		{12345678-1234-1234-1234-123456789012}.Release|Any CPU.ActiveCfg = Release|Any CPU
		{12345678-1234-1234-1234-123456789012}.Release|Any CPU.Build.0 = Release|Any CPU
	EndGlobalSection
EndGlobal";

        var projectContent = @"
<Project Sdk=""Microsoft.NET.Sdk"">
  <PropertyGroup>
    <TargetFramework>net8.0</TargetFramework>
  </PropertyGroup>
</Project>";

        var classContent = @"
using System;

namespace TestNamespace
{
    public class TestClass
    {
        public void TestMethod()
        {
            Console.WriteLine(""Hello World"");
        }
    }
}";

        File.WriteAllText(_testSolutionPath, solutionContent);
        File.WriteAllText(Path.Combine(_testDirectory, "TestProject.csproj"), projectContent);
        File.WriteAllText(_testFilePath, classContent);
    }

    public void Dispose()
    {
        try
        {
            if (Directory.Exists(_testDirectory))
            {
                Directory.Delete(_testDirectory, true);
            }
        }
        catch
        {
            // Ignore cleanup errors
        }
    }
}