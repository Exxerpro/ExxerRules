using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;

namespace ExxerFactor.Mcp.Core.SyntaxRewriters;

/// <summary>
/// Rewriter that renames identifiers based on symbol or name maps.
/// </summary>
public class IdentifierRenameRewriter : CSharpSyntaxRewriter
{
    private readonly SemanticModel? _semanticModel;
    private readonly Dictionary<ISymbol, string>? _symbolMap;
    private readonly Dictionary<string, string>? _nameMap;

    /// <summary>
    /// Initializes a new instance of the <see cref="IdentifierRenameRewriter"/> class.
    /// </summary>
    /// <param name="semanticModel">Optional semantic model to resolve symbols.</param>
    /// <param name="symbolMap">Optional map from symbols to replacement names.</param>
    /// <param name="nameMap">Optional map from raw identifier text to replacement names.</param>
    public IdentifierRenameRewriter(
        SemanticModel? semanticModel = null,
        Dictionary<ISymbol, string>? symbolMap = null,
        Dictionary<string, string>? nameMap = null)
    {
        _semanticModel = semanticModel;
        _symbolMap = symbolMap;
        _nameMap = nameMap;
    }

    /// <inheritdoc />
    public override SyntaxNode? VisitIdentifierName(IdentifierNameSyntax node)
    {
        if (_semanticModel != null && _symbolMap != null)
        {
            var sym = _semanticModel.GetSymbolInfo(node).Symbol;
            if (sym != null && _symbolMap.TryGetValue(sym, out var newName))
                return SyntaxFactory.IdentifierName(newName).WithTriviaFrom(node);
        }

        if (_nameMap != null && _nameMap.TryGetValue(node.Identifier.ValueText, out var name))
            return SyntaxFactory.IdentifierName(name).WithTriviaFrom(node);

        return base.VisitIdentifierName(node);
    }
}