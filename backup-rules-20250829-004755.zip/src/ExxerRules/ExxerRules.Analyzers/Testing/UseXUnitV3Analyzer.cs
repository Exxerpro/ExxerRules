using System.Collections.Immutable;
using System.Linq;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.CodeAnalysis.Diagnostics;

namespace ExxerRules.Analyzers.Testing;

/// <summary>
/// Analyzer that enforces XUnit v3 usage for testing.
/// </summary>
[DiagnosticAnalyzer(LanguageNames.CSharp)]
public class UseXUnitV3Analyzer : DiagnosticAnalyzer
{
	private static readonly LocalizableString Title = "Use XUnit v3 for testing";
	private static readonly LocalizableString MessageFormat = "Use XUnit v3 instead of '{0}' for testing";
	private static readonly LocalizableString Description = "XUnit v3 should be used for all testing instead of other testing frameworks like MSTest or NUnit.";

	private static readonly DiagnosticDescriptor Rule = new(
		DiagnosticIds.UseXUnitV3,
		Title,
		MessageFormat,
		DiagnosticCategories.Testing,
		DiagnosticSeverity.Warning,
		isEnabledByDefault: true,
		description: Description);

	/// <inheritdoc/>
	public override ImmutableArray<DiagnosticDescriptor> SupportedDiagnostics => ImmutableArray.Create(Rule);

	/// <inheritdoc/>
	public override void Initialize(AnalysisContext context)
	{
		context.ConfigureGeneratedCodeAnalysis(GeneratedCodeAnalysisFlags.None);
		context.EnableConcurrentExecution();

		context.RegisterSyntaxNodeAction(AnalyzeAttribute, SyntaxKind.Attribute);
		context.RegisterSyntaxNodeAction(AnalyzeUsingDirective, SyntaxKind.UsingDirective);
	}

	private static void AnalyzeAttribute(SyntaxNodeAnalysisContext context)
	{
		var attribute = (AttributeSyntax)context.Node;
		var attributeName = attribute.Name.ToString();

		// Check for forbidden testing framework attributes
		var forbiddenAttributes = new[]
		{
			"TestMethod",
			"TestClass",
			"TestInitialize",
			"TestCleanup",
			"ClassInitialize",
			"ClassCleanup",
			"AssemblyInitialize",
			"AssemblyCleanup",
			"Test",
			"TestCase",
			"TestFixture",
			"SetUp",
			"TearDown",
			"OneTimeSetUp",
			"OneTimeTearDown",
			"TestFixtureSetUp",
			"TestFixtureTearDown"
		};

		foreach (var forbidden in forbiddenAttributes)
		{
			if (attributeName == forbidden || attributeName.EndsWith("." + forbidden))
			{
				var framework = GetFrameworkName(forbidden);
				var diagnostic = Diagnostic.Create(
					Rule,
					attribute.GetLocation(),
					framework);

				context.ReportDiagnostic(diagnostic);
				break;
			}
		}
	}

	private static void AnalyzeUsingDirective(SyntaxNodeAnalysisContext context)
	{
		var usingDirective = (UsingDirectiveSyntax)context.Node;
		var namespaceName = usingDirective.Name?.ToString();

		if (namespaceName == null)
		{
			return;
		}

		// Allow current Xunit usage (this is effectively XUnit v3 or the current version)
		if (namespaceName == "Xunit")
		{
			return; // Don't report diagnostic for current Xunit usage
		}

		// Check for other forbidden testing framework namespaces
		var forbiddenNamespaces = new[]
		{
			"Microsoft.VisualStudio.TestTools.UnitTesting",
			"NUnit.Framework",
			"NUnit"
		};

		foreach (var forbidden in forbiddenNamespaces)
		{
			if (namespaceName == forbidden || namespaceName.StartsWith(forbidden + "."))
			{
				var framework = GetFrameworkNameFromNamespace(forbidden);
				var diagnostic = Diagnostic.Create(
					Rule,
					usingDirective.GetLocation(),
					framework);

				context.ReportDiagnostic(diagnostic);
				break;
			}
		}
	}

	private static string GetFrameworkName(string attributeName) => attributeName switch
	{
		"TestMethod" or "TestClass" or "TestInitialize" or "TestCleanup" or
		"ClassInitialize" or "ClassCleanup" or "AssemblyInitialize" or "AssemblyCleanup" => "MSTest",
		"Test" or "TestCase" or "TestFixture" or "SetUp" or "TearDown" or
		"OneTimeSetUp" or "OneTimeTearDown" or "TestFixtureSetUp" or "TestFixtureTearDown" => "NUnit",
		_ => "unknown testing framework"
	};

	private static string GetFrameworkNameFromNamespace(string namespaceName) => namespaceName switch
	{
		var ns when ns.StartsWith("Microsoft.VisualStudio.TestTools.UnitTesting") => "MSTest",
		var ns when ns.StartsWith("NUnit") => "NUnit",
		_ => "unknown testing framework"
	};
}
